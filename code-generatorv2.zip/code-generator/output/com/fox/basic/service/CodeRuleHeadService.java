package com.fox.basic.service;

import com.fox.basic.service.BaseService;
import com.fox.basic.vo.request.CodeRuleHeadVo;
/**
 *
 * @Title: 编码规则头表业务逻辑访问接口
 * @Description: 
 * @Copyright:
 * @Company:
 * @author
 * @date 2018-10-24 16:21:40
 * @version 1.0
 *
 */
public interface CodeRuleHeadService extends BaseService<CodeRuleHeadVo> {

}