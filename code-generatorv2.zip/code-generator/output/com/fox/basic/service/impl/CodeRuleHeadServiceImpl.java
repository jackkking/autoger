package com.fox.basic.service.impl;

import com.fox.basic.service.impl.BaseServiceImpl;
import org.springframework.stereotype.Service;
import com.fox.basic.vo.request.CodeRuleHeadVo;
import com.fox.basic.mapper.CodeRuleHeadMapper;
import com.fox.basic.service.CodeRuleHeadService;

/**
 *
 * @Title: 编码规则头表业务逻辑实现类
 * @Description: 
 * @Copyright:
 * @Company:
 * @author
 * @date 2018-10-24 16:21:40
 * @version 1.0
 *
 */
@Service("codeRuleHeadService")
public class CodeRuleHeadServiceImpl extends BaseServiceImpl<CodeRuleHeadMapper, CodeRuleHeadVo> implements CodeRuleHeadService{

}
