package com.fox.basic.controller;

import com.fox.basic.controller.BaseController;
import com.fox.basic.exception.BusinessException;
import com.fox.basic.model.RestResult;
import com.fox.basic.util.ExcelUtiles;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import javax.validation.constraints.Size;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import org.springframework.validation.BindingResult;
import javax.validation.constraints.Max;
import org.springframework.web.multipart.MultipartFile;
import java.util.*;
import com.fox.basic.vo.request.CodeRuleHeadVo;
import com.fox.basic.service.CodeRuleHeadService;



/**
     * CodeRuleHeadController
     * 编码规则头表控制层
     * @date 2018-10-18 16:13:01
	 */
@RestController
@Api(value="CodeRuleHeadController",tags = "CodeRuleHeadVo",description ="编码规则头表")
@RequestMapping(value="/codeRuleHeads")
@Log4j2
@Validated
public class CodeRuleHeadController extends BaseController{
	@Autowired
	private CodeRuleHeadService codeRuleHeadService;

	/**
     * 查询数据列表-分页
     * @date 2018-10-24 16:21:40
	 * @param customer ：CodeRuleHeadVo
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
 	@ApiOperation(value = "查询列表带分页-queryPageList", notes = "输入的参数未对象", httpMethod = "POST")
    @ApiResponses({@ApiResponse(code=500,message = "system inner error-系统错误")})
	@PostMapping("/queryPageList")
	public RestResult queryPageList(@ModelAttribute CodeRuleHeadVo  codeRuleHeadVo)throws BusinessException{

		return returnSuccess(codeRuleHeadService.queryPageList(codeRuleHeadVo));
	}

	/**
     * 按条件查询数据
     * @date 2018-10-24 16:21:40
	 * @param customer ： CodeRuleHeadVo
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
 	@ApiOperation(value = "按条件查询-list", notes = "输入的参数为对象", httpMethod = "POST")
    @ApiResponses({@ApiResponse(code=500,message = "system inner error-系统错误")})
	@PostMapping("/list")
	public RestResult list(@RequestBody CodeRuleHeadVo  codeRuleHeadVo)throws BusinessException{

		return returnSuccess(codeRuleHeadService.findList(codeRuleHeadVo));
	}

	/**
     * 查询单个对象
     * @date 2018-10-24 16:21:40
	 * @param customer ：ID
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
 	@ApiOperation(value = "查询单个对象-query", notes = "输入的参数为数据ID", httpMethod ="GET")
    @ApiResponses({@ApiResponse(code=500,message = "system inner error-系统错误")})
	@GetMapping("/query")
	public RestResult query(@Size(max = 255) @RequestParam(value = "id")String id)throws BusinessException{

		return returnSuccess(codeRuleHeadService.get(id));
	}

	/**
     * 新增
     * @date 2018-10-24 16:21:40
	 * @param body ：CodeRuleHeadVo
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
    @ApiOperation(value = "新增-add", notes = "输入的参数为对象", httpMethod = "POST")
    @ApiResponses({@ApiResponse(code=500,message = "system inner error-系统错误")})
	@PostMapping("/add")
	public RestResult save(@ModelAttribute @Valid CodeRuleHeadVo  codeRuleHeadVo,BindingResult result)throws BusinessException{
		try {

			int flag=codeRuleHeadService.saveOrUpdate(codeRuleHeadVo);
			if(flag==0){
				return returnFailed();
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			return returnFailed();
		}
		return returnSuccess();
	}
    /**
     * 删除
     * @date 2018-10-24 16:21:40
	 * @param body ：CodeRuleHeadVo
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
    @ApiOperation(value = "删除-delete", notes = "输入的参数为对象", httpMethod = "POST")
    @ApiResponses({@ApiResponse(code=500,message = "system inner error-系统错误")})
	@PostMapping("/delete")
	public RestResult delete(@ModelAttribute CodeRuleHeadVo codeRuleHeadVo)throws BusinessException{
		try {

			int flag=codeRuleHeadService.deleteByEntity(codeRuleHeadVo);
			if(flag==0){
				return returnFailed();
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			return returnFailed();
		}
		return returnSuccess();
	}
     /**
     * 更新
     * @date 2018-10-24 16:21:40
	 * @param body ：CodeRuleHeadVo
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
    @ApiOperation(value = "更新-update", notes = "输入的参数为对象", httpMethod = "POST")
    @ApiResponses({@ApiResponse(code=500,message = "system inner error-系统错误")})
	@PostMapping("/update")
	public RestResult update(@ModelAttribute CodeRuleHeadVo  codeRuleHeadVo)throws BusinessException{
		try {

			int flag=codeRuleHeadService.saveOrUpdate(codeRuleHeadVo);
			if(flag==0){
				return returnFailed();
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			return returnFailed();
		}
		return returnSuccess();
	}
     /**
     * 导出EXCEL
     * @date 2018-10-24 16:21:40
	 * @param body ：CodeRuleHeadVo
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "导出", notes = "输入的参数为对象",httpMethod = "POST")
	@ApiResponses({@ApiResponse(code=500,message = "system inner error-系统错误")})
	@GetMapping(value="/export" )
	public void export(@RequestBody  CodeRuleHeadVo  codeRuleHeadVo,HttpServletResponse response) throws BusinessException {
		try {
			 List<CodeRuleHeadVo> listCodeRuleHeadVo=codeRuleHeadService.findList(codeRuleHeadVo);
             ExcelUtiles.exportExcel(listCodeRuleHeadVo, "编码规则头表", "编码规则头表", CodeRuleHeadVo.class, "编码规则头表.xls", response);
	    } catch (Exception e) {
             e.printStackTrace();
             log.error(e.getMessage());

        }

    }
    /**
    * 导入EXCEL
    * @date 2018-10-24 16:21:40
    * @param body
    * @param request
    * @param response
    * @return
    * @throws Exception
    */
    @ApiOperation(value = "导入", notes = "文件", httpMethod = "POST")
    @ApiResponses({@ApiResponse(code=500,message = "system inner error-系统错误")})
    @PostMapping(value="/uplod")
    public void text(@RequestParam("file")MultipartFile file , HttpServletRequest request) throws BusinessException {
        try {
             ImportParams importParams=new ImportParams();
	         List<Map<String,Object>> result=ExcelImportUtil.importExcel(file.getInputStream(),Map.class,importParams);
        } catch (Exception e) {
	         e.printStackTrace();
             log.error(e.getMessage());
        }
    }

}
