package com.fox.basic.mapper;

import org.apache.ibatis.annotations.Mapper;
import com.fox.basic.mapper.MapperBase;
import com.fox.basic.vo.request.CodeRuleHeadVo;

/**
 *
 * @Title: 编码规则头表数据库访问接口
 * @Description: 
 * @Copyright:
 * @Company:
 * @author
 * @date 2018-10-24 16:21:40
 * @version 1.0
 *
 */
@Mapper
public interface CodeRuleHeadMapper extends MapperBase<CodeRuleHeadVo> {
	
}